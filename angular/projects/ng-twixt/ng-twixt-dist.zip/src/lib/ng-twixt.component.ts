import { Component } from '@angular/core';

@Component({
  selector: 'lib-ng-twixt',
  standalone: true,
  imports: [],
  template: `
    <p>
      ng-twixt works!
    </p>
  `,
  styles: ``
})
export class NgTwixtComponent {

}
