/*
 * Public API Surface of ng-twixt
 */

export * from './lib/ng-twixt.service';
export * from './lib/ng-twixt.component';
